-- Adminer 4.8.1 MySQL 5.7.39 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `books`;
CREATE TABLE `books` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` char(150) NOT NULL,
  `year` year(4) NOT NULL,
  `description` varchar(2000) NOT NULL,
  `cover` varchar(500) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `title` (`title`),
  KEY `year` (`year`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `books` (`id`, `title`, `year`, `description`, `cover`, `created_at`, `updated_at`) VALUES
(16,	'Портрет Дориана Грея',	'2022',	'\"Портрет Дориана Грея\" — самое знаменитое произведение Оскара Уайльда, единственный его роман, вызвавший в свое время шквал негативных оценок и тем не менее имевший невероятный успех.\r\nГлавный герой романа, красавец Дориан, — фигура двойственная, неоднозначная. Т',	'/storage/images/KixTaRqAHOeIIqo2AnkXYSmuxZwePnOxYYVWt0Yf.jpg',	'2024-02-21 15:18:55',	'2024-02-24 23:31:31'),
(17,	'Холодный дом',	'2023',	'Оказавшись на попечении случайного благодетеля мистера Джарндиса, она по окончании пансиона попадает в его старинное поместье, известное как Холодный дом, с которым связано едва ли не самое известное дело Верховного Канцлерского суда «Джарндисы против Джарндисов».',	'/storage/images/N5xtBbtgIRHRU7Xhfv1hV2hJZDq83C2EUsZqZogb.jpg',	'2024-02-21 15:20:45',	'2024-02-24 17:48:44'),
(18,	'Мастер и Маргарита',	'2023',	'В Москву прибыл дьявол со своей свитой, и началась череда невероятных происшествий. В это время талантливый мастер томится в доме скорби, а его возлюбленная Маргарита пытается его спасти. Творчество или ремесло, благополучие или страсть, справедливость или карьера, свет или тьма… Каждый из героев делает собственный выбор, который становится вкладом в вечную борьбу добра и зла. Самый известный и неоднозначный роман XX века в современном оформлении для всех, кто хочет открыть \"Мастера и Маргариту\" впервые или перечитать.',	'/storage/images/J01lpNCuL3I2GLsTSZWcYHy9qlcrJHcTbA1HKmfi.jpg',	'2024-02-21 15:21:35',	'2024-02-24 17:48:37'),
(19,	'Гордость и предубеждение',	'2022',	'самый популярный женский роман в мире, провозглашенный интернет-пользователями Великобритании одной из лучших книг всех времен и народов.\r\nМистер Дарси – главный герой романа – стал для многих читательниц эталоном мужчины, благородный аристократ, который закрывает глаза на сословные предрассудки и женится по любви на женщине, стоящей гораздо ниже его по положению. На Элизабет Беннет, гордой, неприступной девушке, умной, начитанной и глубоко чувствующей.',	'/storage/images/aH6ERABMM432ODYMuAB4D7sn895EK3rxE3C5PCq9.jpg',	'2024-02-21 15:22:27',	'2024-02-24 17:48:25'),
(20,	'Три товарища',	'2022',	'Самый красивый в двадцатом столетии роман о любви...\r\nСамый увлекательный в двадцатом столетии роман о дружбе...\r\nСамый трагический и пронзительный роман о человеческих отношениях за всю историю двадцатого столетия.',	'/storage/images/ZVijgimAdPzUqLiQCT3sdv4Kn4ttpWnZqHdWNu59.jpg',	'2024-02-21 15:23:06',	'2024-02-24 17:48:14'),
(21,	'Мартин Иден',	'2022',	'\"Мартин Иден\" — самый известный роман Джека Лондона, впервые напечатанный в 1908-1909 гг.\r\nВо многом автобиографическая книга о человеке, который \"сделал себя сам\", выбравшись из самых низов, добился признания. Любовь к девушке из высшего общества побуждает героя заняться самообразованием.',	'/storage/images/qreCEr3XWoG9g53d3OATfhbs1ViLmkvSg6hVG10y.jpg',	'2024-02-21 15:23:46',	'2024-02-24 17:48:03'),
(22,	'Дежавю',	'2024',	'Репортер местной газеты Керри Мильтон узнает из теленовостей о гибели известного профессора. Вот только некролог на него он уже писал, и на похоронах тоже был… двадцать лет назад. В поисках его надгробия журналист отправляется на то самое кладбище, но вместо старой могилы находит новую на том же месте.',	'/storage/images/OZaYw7JnHtU6irkrb08kceuF6yOaleAXIOFAg8k7.jpg',	'2024-02-21 15:27:27',	'2024-02-24 17:47:51'),
(23,	'Происшествие в городе Т.',	'2024',	'На губернатора Татаяра совершено покушение в его собственной карете. Орудие преступления вызывает у полиции лишь улыбку, ведь это – обычная серебряная ложка, и нападавший просто душевнобольной. Но вскоре начальник сыскной полиции барон фон Шпинне начинает понимать, что губернатору грозит серьезная опасность.',	'/storage/images/Nj6mtkRe3dv75I4wRvk5MTqrQMI0S4Zuc0eINYI9.jpg',	'2024-02-21 15:28:04',	'2024-02-24 17:47:41'),
(24,	'Тринадцатая карта',	'2023',	'Детективы Ханна Шор и Бернард Глэдвин начинают расследование смерти Жаклин Мьюн, погибшей от двух пулевых ранений. Но то, что поначалу выглядит случайной стрельбой в неблагополучном районе, оказывается намного сложнее. Жаклин была экстрасенсом, предсказательницей судьбы и знахаркой, гадала на картах Таро и продавала экзотические снадобья, травы и масла. И очень много у кого вокруг были причины желать ее смерти.',	'/storage/images/eCIdwbzVs9mVhyYzsfaNq0CZ9S6U7hRlhaWdpCx7.jpg',	'2024-02-21 15:28:55',	'2024-02-24 17:47:34'),
(25,	'Десять негритят',	'2022',	'Роман «Десять негритят» — один из величайших детективных произведений в истории. Выпущенный общим тиражом более 100 000 000 экземпляров, он занимает пятое место в списке бестселлеров художественной литературы всех времен — и безусловное первое место среди романов самой Агаты Кристи.',	'/storage/images/amWw8pBxlP4yevFFdvGd7zombedSgcZxvcFUUS4c.jpg',	'2024-02-21 15:29:37',	'2024-02-24 17:47:14'),
(26,	'Посмотри, отвернись, посмотри',	'2020',	'Но точка пересечения этих миров — жестокое убийство, погружающее в темные и страшные тайны.\r\nЕсли что-то на первый взгляд кажется тебе милым, ясным и привлекательным, остановись. Отвернись. Посмотри ещё раз. Вглядись пристально. Прислушайся к своей интуиции. Если она кричит: \"Спасайся!\" — не жди, пока на помощь придут частные детективы Макар Илюшин и Сергей Бабкин.\r\nОни могут не успеть.',	'/storage/images/EPGoZKohgbidcqXGLA3VkGBi2U1wQ6HmQSEBtDyy.jpg',	'2024-02-21 15:30:30',	'2024-02-24 19:18:31');

DROP TABLE IF EXISTS `books_categories`;
CREATE TABLE `books_categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `books_id` bigint(20) unsigned NOT NULL,
  `categories_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `books_id` (`books_id`),
  KEY `categories_id` (`categories_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `books_categories` (`id`, `books_id`, `categories_id`) VALUES
(1,	16,	1),
(2,	17,	1),
(3,	18,	1),
(4,	19,	1),
(5,	20,	1),
(6,	21,	1),
(7,	22,	2),
(8,	23,	2),
(9,	24,	2),
(10,	25,	2),
(11,	26,	2);

DROP TABLE IF EXISTS `books_writers`;
CREATE TABLE `books_writers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `books_id` bigint(20) unsigned NOT NULL,
  `writers_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `books_writers` (`id`, `books_id`, `writers_id`) VALUES
(1,	16,	8),
(2,	17,	9),
(3,	18,	10),
(4,	19,	11),
(5,	20,	12),
(6,	21,	13),
(7,	22,	3),
(8,	23,	4),
(9,	24,	5),
(10,	25,	6),
(11,	26,	7);

DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` char(150) DEFAULT NULL,
  `slug` char(150) DEFAULT NULL,
  `description` varchar(500) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `categories` (`id`, `title`, `slug`, `description`, `created_at`, `updated_at`) VALUES
(1,	'Классика',	'klassika',	'Понятие классики в литературе складывалось в три последних столетия античности: оно обозначало определённую категорию писателей, которые по не всегда ясным причинам (в силу древности или авторитета в глазах просвещённых людей) считались достойными служить образцами и наставниками во всём, что касается владения словом и получения знаний. Первым классическим автором, безусловно, считался Гомер.',	'2024-02-22 10:13:32',	'2024-02-24 22:00:20'),
(2,	'Детектив',	'detective',	'Важное свойство классического детектива — полнота фактов, поскольку «придумать хорошую загадку легче, чем хорошую разгадку (характерный пример — некоторые романы Джона Диксона Карра)». Разгадка тайны не может строиться на сведениях, которые не были предоставлены читателю в ходе описания расследования',	'2024-02-22 10:14:23',	'2024-02-25 18:09:15');

DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1,	'2014_10_12_000000_create_users_table',	1),
(2,	'2014_10_12_100000_create_password_reset_tokens_table',	1),
(3,	'2019_08_19_000000_create_failed_jobs_table',	1),
(4,	'2019_12_14_000001_create_personal_access_tokens_table',	1);

DROP TABLE IF EXISTS `password_reset_tokens`;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `personal_access_tokens`;
CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `personal_access_tokens` (`id`, `tokenable_type`, `tokenable_id`, `name`, `token`, `abilities`, `last_used_at`, `expires_at`, `created_at`, `updated_at`) VALUES
(1,	'App\\Models\\User',	1,	'auth_token',	'd18b59541d2670f44e5f46df6664e916db5886f15523fdc26bf6b099a4474fae',	'[\"*\"]',	NULL,	NULL,	'2024-02-20 11:30:46',	'2024-02-20 11:30:46'),
(2,	'App\\Models\\User',	1,	'auth_token',	'b355a7a4125eeaf81296bd830ff3f61fa918524143dd8b871a628b96fe0e0e34',	'[\"*\"]',	NULL,	NULL,	'2024-02-20 11:30:56',	'2024-02-20 11:30:56'),
(3,	'App\\Models\\User',	1,	'auth_token',	'062cdc47b7fb25d3bc5e42ee3585504445226f4c839d70e19b4a46fdb3eea5f9',	'[\"*\"]',	NULL,	NULL,	'2024-02-20 11:33:56',	'2024-02-20 11:33:56'),
(4,	'App\\Models\\User',	1,	'auth_token',	'd95f36975c73e0f78baf197fc249c4330f1477e7ce6aa20b4e007b2588994644',	'[\"*\"]',	NULL,	NULL,	'2024-02-20 11:40:49',	'2024-02-20 11:40:49'),
(5,	'App\\Models\\User',	1,	'auth_token',	'0101c027d7378edabaa579411ef1877a9896a62653499c3725810ea5a67bb04b',	'[\"*\"]',	NULL,	NULL,	'2024-02-20 12:10:40',	'2024-02-20 12:10:40'),
(6,	'App\\Models\\User',	1,	'auth_token',	'de7c3b855e97e3eb376a56203e1c8e2fd376b47984f5954df6f2c3fc96280628',	'[\"*\"]',	NULL,	NULL,	'2024-02-20 13:30:26',	'2024-02-20 13:30:26'),
(7,	'App\\Models\\User',	1,	'auth_token',	'b8f31a3082bd0975c40ab18269c6840eee2982d759aa0ec9c1bbdf2a41419976',	'[\"*\"]',	NULL,	NULL,	'2024-02-20 13:30:38',	'2024-02-20 13:30:38'),
(8,	'App\\Models\\User',	1,	'auth_token',	'174a6bc5c7e3d559f63019d8fb6e49f3fcb2ee9f1f00839c36b43adac1ff979c',	'[\"*\"]',	NULL,	NULL,	'2024-02-20 13:31:13',	'2024-02-20 13:31:13'),
(9,	'App\\Models\\User',	1,	'auth_token',	'cef85dc6e009b67204e4195824ab7b8544116cb8a50a08f3b9f1149e477edba9',	'[\"*\"]',	NULL,	NULL,	'2024-02-20 13:31:28',	'2024-02-20 13:31:28'),
(10,	'App\\Models\\User',	1,	'auth_token',	'f1c06fe0baf150e689656ae41101302912bd1d2c074612809b8561afdaffc17c',	'[\"*\"]',	NULL,	NULL,	'2024-02-20 13:31:57',	'2024-02-20 13:31:57'),
(11,	'App\\Models\\User',	1,	'auth_token',	'70f8dc5e6980041c0b18c6da8ab57ce58a0da42242aa3cadc8bd84c0f111e381',	'[\"*\"]',	NULL,	NULL,	'2024-02-20 13:33:09',	'2024-02-20 13:33:09'),
(12,	'App\\Models\\User',	1,	'auth_token',	'4794eedb5242c282cc7a8a774c963585100fbc61934858ae2c7e7787c11cf27b',	'[\"*\"]',	NULL,	NULL,	'2024-02-20 13:33:36',	'2024-02-20 13:33:36'),
(13,	'App\\Models\\User',	1,	'auth_token',	'a9cfb344b5a91943c2127829047f0f3068be9cfeafd16595138935cf61f98c23',	'[\"*\"]',	NULL,	NULL,	'2024-02-20 13:36:30',	'2024-02-20 13:36:30'),
(14,	'App\\Models\\User',	2,	'auth_token',	'4c16e27640de14436e1128b42d4437c8eab2decd2ce78810851170fcf70bc827',	'[\"*\"]',	NULL,	NULL,	'2024-02-20 13:37:13',	'2024-02-20 13:37:13'),
(15,	'App\\Models\\User',	1,	'auth_token',	'97ef870610643050c4713891ae6be27b039ad195ac886edecd7b8d7062aad7b4',	'[\"*\"]',	NULL,	NULL,	'2024-02-20 13:41:17',	'2024-02-20 13:41:17'),
(16,	'App\\Models\\User',	1,	'auth_token',	'617e1a3b1f988d3a0f7084a0a07d775a04fbe164309593330906ee641f5376eb',	'[\"*\"]',	NULL,	NULL,	'2024-02-20 13:42:16',	'2024-02-20 13:42:16'),
(17,	'App\\Models\\User',	1,	'auth_token',	'0d1e9d899cd03015e982aa2a1192a0e188b454365219c7595f83991608412b82',	'[\"*\"]',	NULL,	NULL,	'2024-02-20 13:46:29',	'2024-02-20 13:46:29'),
(18,	'App\\Models\\User',	1,	'auth_token',	'37a0d1283a1ac0d38e7421bed7711fd39b5c1a9dc3ccf559347a1d086a32a7fa',	'[\"*\"]',	NULL,	NULL,	'2024-02-20 15:40:09',	'2024-02-20 15:40:09'),
(19,	'App\\Models\\User',	1,	'auth_token',	'21e6ccb2213a7b72243767afe1c34455b7fe02da8d3fecd95efb8d1af700ed79',	'[\"*\"]',	NULL,	NULL,	'2024-02-20 16:44:33',	'2024-02-20 16:44:33'),
(20,	'App\\Models\\User',	1,	'auth_token',	'd22e81cc0fdf373b91023e71ef5206a9bfc6c7cbb7e77f7f421ecfa91dabe60d',	'[\"*\"]',	NULL,	NULL,	'2024-02-20 16:45:29',	'2024-02-20 16:45:29'),
(21,	'App\\Models\\User',	1,	'auth_token',	'7c56eac0f95116bcb7e443a39398dcb08cc304266470f9b69890920ac8bf4f02',	'[\"*\"]',	NULL,	NULL,	'2024-02-20 16:47:17',	'2024-02-20 16:47:17'),
(22,	'App\\Models\\User',	1,	'auth_token',	'f7c72a8e1247a7db643bf81f5f4bb5572dccfc6d24c23a30cee8bb923be50b04',	'[\"*\"]',	NULL,	NULL,	'2024-02-20 16:52:51',	'2024-02-20 16:52:51'),
(23,	'App\\Models\\User',	1,	'auth_token',	'b7d919b8ba8406a534c7261cdd27e85f23331539fa68f136613e25c7fd2191f4',	'[\"*\"]',	NULL,	NULL,	'2024-02-20 17:16:46',	'2024-02-20 17:16:46'),
(24,	'App\\Models\\User',	1,	'auth_token',	'cf5ae4fa5b82a498afcba10ab3653b0ed6f3e4da07437c93bc686a346e49b07a',	'[\"*\"]',	NULL,	NULL,	'2024-02-20 17:22:25',	'2024-02-20 17:22:25'),
(25,	'App\\Models\\User',	1,	'auth_token',	'af5369f452fa42f1475b8ad7e23cd16c3a36b2aaae9f7f0a3bd8cdc209ed14fa',	'[\"*\"]',	NULL,	NULL,	'2024-02-20 17:45:43',	'2024-02-20 17:45:43'),
(26,	'App\\Models\\User',	1,	'auth_token',	'4b81c4b614668bd37e411b7c340c41da308a543988be59e5488f03364fdf9076',	'[\"*\"]',	NULL,	NULL,	'2024-02-20 17:51:42',	'2024-02-20 17:51:42'),
(27,	'App\\Models\\User',	1,	'auth_token',	'904d437f78a85d83a7ec7012d285fded11f84514dcc7998f653dda0df1a36560',	'[\"*\"]',	NULL,	NULL,	'2024-02-20 17:53:10',	'2024-02-20 17:53:10'),
(28,	'App\\Models\\User',	1,	'auth_token',	'2e6c031acc1c15526f7d325e2d1422995d9fbcf6637a84decf1330494b1dcfa0',	'[\"*\"]',	NULL,	NULL,	'2024-02-20 18:17:24',	'2024-02-20 18:17:24'),
(29,	'App\\Models\\User',	1,	'auth_token',	'bc02111e8feea2668a377232811da84cedcc5476150f41cd6ffe334c4c0f5e39',	'[\"*\"]',	NULL,	NULL,	'2024-02-20 18:21:26',	'2024-02-20 18:21:26'),
(30,	'App\\Models\\User',	1,	'auth_token',	'08955d2bf4ba41d5338402c509c70845166885730cd7b2872f341ecf0d186c5c',	'[\"*\"]',	NULL,	NULL,	'2024-02-20 18:25:02',	'2024-02-20 18:25:02'),
(31,	'App\\Models\\User',	1,	'auth_token',	'1b912be765ea69984842f55b66958c3293bcf6e432fe948bca4afdbdac70acf9',	'[\"*\"]',	NULL,	NULL,	'2024-02-20 18:35:26',	'2024-02-20 18:35:26'),
(32,	'App\\Models\\User',	1,	'auth_token',	'9038c4201e42af08ccd70b32ac549140d3e60c16d319916805670765e7019c1a',	'[\"*\"]',	NULL,	NULL,	'2024-02-20 18:39:12',	'2024-02-20 18:39:12'),
(33,	'App\\Models\\User',	1,	'auth_token',	'1729e6178cc0cc09efa7650db4de0ad1fcf653f7a6c70261361f2d87b91cc133',	'[\"*\"]',	NULL,	NULL,	'2024-02-20 18:41:26',	'2024-02-20 18:41:26'),
(34,	'App\\Models\\User',	1,	'auth_token',	'81451590a92e5884c84b4da58f50187fcd1ab3d36ebf4ef5bbc1f75d2274781b',	'[\"*\"]',	NULL,	NULL,	'2024-02-20 18:44:16',	'2024-02-20 18:44:16'),
(35,	'App\\Models\\User',	1,	'auth_token',	'ef13e251c18018975dc102d7b5f483200fa23a49be83786f098bd88a76839592',	'[\"*\"]',	NULL,	NULL,	'2024-02-20 18:45:20',	'2024-02-20 18:45:20'),
(36,	'App\\Models\\User',	1,	'auth_token',	'dbe688813f48a4ca7e3752c0316b98bf4dd21f6e7450bcb4e83b31f0bdb37b02',	'[\"*\"]',	NULL,	NULL,	'2024-02-20 18:47:53',	'2024-02-20 18:47:53'),
(37,	'App\\Models\\User',	1,	'auth_token',	'64fb39851dcb18fc0fa616f33ba99dfb1b504e6e509c3f78f559a11596105ff6',	'[\"*\"]',	NULL,	NULL,	'2024-02-20 18:49:05',	'2024-02-20 18:49:05'),
(38,	'App\\Models\\User',	1,	'auth_token',	'08fcd4d204b76e62b3ce45841365f521808df1f4416cd15975a483b3f61710b3',	'[\"*\"]',	NULL,	NULL,	'2024-02-20 18:49:26',	'2024-02-20 18:49:26'),
(39,	'App\\Models\\User',	1,	'auth_token',	'aa03f335f20a2082cf2b763f0afeec0e8b948f2e1ace88d94a36b2973de71cdf',	'[\"*\"]',	NULL,	NULL,	'2024-02-20 18:50:50',	'2024-02-20 18:50:50'),
(40,	'App\\Models\\User',	1,	'auth_token',	'cc84b7f71e70b261854c6f907a27b0fa41feeba48bdc85285bbfca8bf779d25c',	'[\"*\"]',	NULL,	NULL,	'2024-02-20 18:58:24',	'2024-02-20 18:58:24'),
(41,	'App\\Models\\User',	1,	'auth_token',	'b745d70cd0c803944b75054a0871e5ff4942cfdf620b92bfeb3007d33a0a75ec',	'[\"*\"]',	NULL,	NULL,	'2024-02-20 19:14:15',	'2024-02-20 19:14:15'),
(42,	'App\\Models\\User',	1,	'auth_token',	'5fa5c4609805fc2bbf0d70ee517afa9163bd3f21c5c4c63f0f474bcaac6216bd',	'[\"*\"]',	NULL,	NULL,	'2024-02-20 19:31:57',	'2024-02-20 19:31:57'),
(43,	'App\\Models\\User',	1,	'auth_token',	'5ef5010ba8a7b3abdf943d8b57b1004d449604a3cf12b48b5c38482f9d1face7',	'[\"*\"]',	NULL,	NULL,	'2024-02-20 19:41:16',	'2024-02-20 19:41:16'),
(44,	'App\\Models\\User',	1,	'auth_token',	'f48936df6cd88aee38ce422f53dfec1b473c0043aa8eb7a4f5472b7294ddec9d',	'[\"*\"]',	NULL,	NULL,	'2024-02-20 19:42:43',	'2024-02-20 19:42:43'),
(45,	'App\\Models\\User',	1,	'auth_token',	'1d1da22a5cca9d8c7cb3946212b21f807cb2b47172842e68843d65a1ea3f4d0e',	'[\"*\"]',	NULL,	NULL,	'2024-02-20 19:44:38',	'2024-02-20 19:44:38'),
(46,	'App\\Models\\User',	1,	'auth_token',	'53a3e41e22512dbb07edd064a48d1e766f739d7c7140ef663bcfaa03319bb0a1',	'[\"*\"]',	NULL,	NULL,	'2024-02-20 19:46:48',	'2024-02-20 19:46:48'),
(47,	'App\\Models\\User',	1,	'auth_token',	'796fc0ec09c07b2de6f6f90f7e932e6ada1b225d8653b061a3f27a10320a590a',	'[\"*\"]',	NULL,	NULL,	'2024-02-20 20:16:21',	'2024-02-20 20:16:21'),
(48,	'App\\Models\\User',	3,	'auth_token',	'185cb7e71bf6c157b98cf126a8cf39eec0961d96ccf86ee1cdc1682a7a4688d1',	'[\"*\"]',	NULL,	NULL,	'2024-02-21 04:52:15',	'2024-02-21 04:52:15'),
(49,	'App\\Models\\User',	4,	'auth_token',	'56d84a0a51973b8332c35a3a54eeffeb112cc709382683532ca0fb7f3fcf19bc',	'[\"*\"]',	NULL,	NULL,	'2024-02-21 05:00:24',	'2024-02-21 05:00:24'),
(50,	'App\\Models\\User',	4,	'auth_token',	'd76ae19e9c7666153e07190c617245d53dacf3d4e72aa1abaa4d68a013e943cb',	'[\"*\"]',	NULL,	NULL,	'2024-02-21 05:01:11',	'2024-02-21 05:01:11'),
(51,	'App\\Models\\User',	5,	'auth_token',	'24f3a3f642a0d0e3a11d318e97069cc13bbbbba4846bb832a95644ad82c00369',	'[\"*\"]',	NULL,	NULL,	'2024-02-21 05:07:30',	'2024-02-21 05:07:30'),
(52,	'App\\Models\\User',	6,	'auth_token',	'45bb30e2879811fd618398c107df4f577eba63bba1e8ea4623ed6b637d0541e4',	'[\"*\"]',	NULL,	NULL,	'2024-02-21 05:12:31',	'2024-02-21 05:12:31'),
(53,	'App\\Models\\User',	1,	'auth_token',	'c0c4c23824eb57d62b6a85b5e3fbaae7197cbf7a49db29fbd755851b1f98521e',	'[\"*\"]',	NULL,	NULL,	'2024-02-21 05:14:05',	'2024-02-21 05:14:05'),
(54,	'App\\Models\\User',	1,	'auth_token',	'0516eda3a784fb33ad7a136509754b24f533d0671cf4a314f348e8d5236cdede',	'[\"*\"]',	NULL,	NULL,	'2024-02-21 05:16:31',	'2024-02-21 05:16:31'),
(55,	'App\\Models\\User',	1,	'auth_token',	'8d4376b57c2bc1a296039c0c2a4a971f81a81acc2805c73cf681eb650166a523',	'[\"*\"]',	NULL,	NULL,	'2024-02-21 05:33:53',	'2024-02-21 05:33:53'),
(56,	'App\\Models\\User',	1,	'auth_token',	'3a56b2b799934050d5257a3a5edc27f025e82114cbb4e543302c8b53843fb3f5',	'[\"*\"]',	NULL,	NULL,	'2024-02-21 05:34:57',	'2024-02-21 05:34:57'),
(57,	'App\\Models\\User',	1,	'auth_token',	'90fe4a4bfc84eacb9f292efb30677c2610d55821bae025d8e2cfd3ce9f8898a1',	'[\"*\"]',	NULL,	NULL,	'2024-02-21 07:29:06',	'2024-02-21 07:29:06'),
(58,	'App\\Models\\User',	1,	'auth_token',	'1fb9220b344ae8e060e75b879a16ab8a9978366f63afe742069e52e4ca518055',	'[\"*\"]',	NULL,	NULL,	'2024-02-21 09:23:37',	'2024-02-21 09:23:37'),
(59,	'App\\Models\\User',	1,	'auth_token',	'b9129615269960dc7e024c9daa55f5fefc1f6e0a0e5e1a3b9bccbfcc1f5871d5',	'[\"*\"]',	NULL,	NULL,	'2024-02-21 09:48:02',	'2024-02-21 09:48:02'),
(60,	'App\\Models\\User',	7,	'auth_token',	'346fa3912f524d84102e2d14cc79724f5821e597fc66a23bbcac834f4dba7cc1',	'[\"*\"]',	NULL,	NULL,	'2024-02-21 09:48:37',	'2024-02-21 09:48:37'),
(61,	'App\\Models\\User',	1,	'auth_token',	'9f08438d53475d2fd7471e4f9256c1d946eaa29f31ace74cc38361f96fc657f4',	'[\"*\"]',	'2024-02-21 11:22:59',	NULL,	'2024-02-21 09:51:56',	'2024-02-21 11:22:59'),
(62,	'App\\Models\\User',	1,	'auth_token',	'd3b0a63f52e5023be81a11423bad3c336d16416d56e6d6f26178998267d49dae',	'[\"*\"]',	'2024-02-22 10:14:23',	NULL,	'2024-02-21 11:24:09',	'2024-02-22 10:14:23'),
(63,	'App\\Models\\User',	1,	'auth_token',	'75c12d7417e517d38b29946ff9d8c45edb7a1dc00ce19f01cfed37f8c6ce3670',	'[\"*\"]',	NULL,	NULL,	'2024-02-22 10:32:27',	'2024-02-22 10:32:27'),
(64,	'App\\Models\\User',	1,	'auth_token',	'8ca2f8857b12fe6aa58b3e813869a426f21fb0a6bd1c1676416b32ce4ad95278',	'[\"*\"]',	NULL,	NULL,	'2024-02-22 21:23:39',	'2024-02-22 21:23:39'),
(65,	'App\\Models\\User',	1,	'auth_token',	'34e32307521927f7c409dc3b3f8ea0206898ab64e12b950651420a6977f3f7c9',	'[\"*\"]',	NULL,	NULL,	'2024-02-23 18:01:45',	'2024-02-23 18:01:45'),
(66,	'App\\Models\\User',	1,	'auth_token',	'd8a736d64db2fb69f6c06f73f82de3be572f93e56448e2e6b3fad857e70ff65b',	'[\"*\"]',	NULL,	NULL,	'2024-02-23 18:02:04',	'2024-02-23 18:02:04'),
(67,	'App\\Models\\User',	1,	'auth_token',	'29afb657f6497a808e8cc448442a56906bc106753e3cebb36552647461c098b5',	'[\"*\"]',	NULL,	NULL,	'2024-02-23 18:03:18',	'2024-02-23 18:03:18'),
(68,	'App\\Models\\User',	1,	'auth_token',	'945d92732f9cd0160fe0e344958c77987eb92aea5efdfe0e11d58138bd7a9649',	'[\"*\"]',	NULL,	NULL,	'2024-02-23 18:03:28',	'2024-02-23 18:03:28'),
(69,	'App\\Models\\User',	1,	'auth_token',	'6c82bf31109280f455f5f57125cde1544f3bbf1b707bbe2d2ddb074d853f8db1',	'[\"*\"]',	'2024-02-23 19:21:44',	NULL,	'2024-02-23 18:04:08',	'2024-02-23 19:21:44'),
(70,	'App\\Models\\User',	1,	'auth_token',	'480a58680908cecedbc732566d69404d3bed31f32e7e01961db12cd34ed89060',	'[\"*\"]',	'2024-02-24 17:56:36',	NULL,	'2024-02-24 04:07:10',	'2024-02-24 17:56:36'),
(71,	'App\\Models\\User',	1,	'auth_token',	'db7d7424a2ec9e90dd2ec85fde7d50c74dc370dd2d9fd08598fcb81ca4d4e86e',	'[\"*\"]',	'2024-02-25 15:09:15',	NULL,	'2024-02-24 17:58:15',	'2024-02-25 15:09:15');

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1,	'Dmitriy',	'f.doc2@yandex.ru',	NULL,	'$2y$12$oJyqfr/mq0eBDfrSFWuL.uZwWWeJGuKZW0JrOzxSBYs5ANf.ojvLW',	NULL,	'2024-02-20 11:30:46',	'2024-02-20 11:30:46'),
(7,	'TTT',	'f.doc21@yandex.ru',	NULL,	'$2y$12$4NgYQXFkHNagnfp6S8CrJeM.cIRY26pbweAidcuVj/xypxebBiWOO',	NULL,	'2024-02-21 09:48:37',	'2024-02-21 09:48:37');

DROP TABLE IF EXISTS `writers`;
CREATE TABLE `writers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` char(150) NOT NULL,
  `country` char(100) NOT NULL,
  `comment` varchar(500) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `country` (`country`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `writers` (`id`, `name`, `country`, `comment`, `created_at`, `updated_at`) VALUES
(3,	'Кейли Лора',	'Россия',	'Лора Кейли — автор детективов и мистических триллеров. Родилась в небольшом городке в семье художников. Подробнее: https://www.labirint.ru/authors/254484/',	'2024-02-21 15:36:14',	'2024-02-21 21:52:21'),
(4,	'Брусилов, Лев Алексеевич',	'Российская империя',	'Из дворян Новгородской губернии. Третий и последний сын А. Н. Брусилова, которому при рождении Льва Алексеевича было 68 (по другим данным — 70) лет.  В 1875 году окончил Николаевские морские юнкерские классы Черноморского флота. 13 октября 1876 года зачислен во 2-й Черноморский флотский экипаж. 16 апреля 1878 года произведён в гардемарины.',	'2024-02-21 15:38:36',	'2024-02-21 18:38:36'),
(5,	'Майк Омер',	'Израиль',	'Майкл Омер родился в Иерусалиме в 1979 году. Оба его родителя были психологами. Когда ему было шесть лет, его семья переехала в Бостон на год, чтобы отец смог получить степень доктора наук, в результате переезда Омер научился бегло говорить по-английски. Позже семья вернулась в Израиль и поселилась в Ход-ха-Шарон[6].  С юных лет Омер проявлял писательский талант и был заядлым читателем научной фантастики и фэнтези',	'2024-02-21 15:39:42',	'2024-02-21 18:39:42'),
(6,	'Агата Кристи',	'Великобритания',	'Произведения Агаты Кристи стали одними из самых публикуемых за всю историю человечества(уступая только «Библии» и трудам Уильяма Шекспира), а также — самыми переводимыми(7236 переводов). Она опубликовала более 60 детективных романов, 6 психологических романов (под псевдонимом Mary Westmacott – Мэри Уэстмакотт (Вестмакотт) и 19 сборников рассказов. В театрах Лондона были поставлены 16 её пьес.',	'2024-02-21 15:40:36',	'2024-02-25 18:08:56'),
(7,	'Елена Михалкова',	'СССР',	'Елена Ивановна Михалкова родилась 1 апреля 1983 года в Нижнем Новгороде; там же закончила университет им. Лобачевского, юридический факультет. Работала помощником следователя в милиции. Писала детские стихи и её творчество было замечено Андреем Усачёвым. Писала сценарии для детских телевизионных передач.',	'2024-02-21 15:43:59',	'2024-02-21 21:44:24'),
(8,	'Оскар Уайльд',	'Великобритания',	'Оскар Уайльд родился 16 октября 1854 года в доме 22 по улице Уэстлэнд-роу в Дублине и был вторым ребёнком от брака сэра Уильяма Уайльда (1815—1876) и Джейн Франчески Уайльд (1821—1896).',	'2024-02-21 15:46:07',	'2024-02-21 18:46:07'),
(9,	'Чарльз Диккенс',	'Великобритания',	'Диккенс был среднего роста. Его природная живость и малопредставительная наружность были причиной того, что он производил на окружающих впечатление человека низкорослого или, во всяком случае, очень миниатюрного сложения. В молодости на его голове была чересчур экстравагантная, даже для той эпохи, шапка каштановых волос, а позже он носил тёмные усы и густую, пышную, тёмную эспаньолку такой оригинальной формы, что она делала его похожим на иностранца.',	'2024-02-21 15:46:52',	'2024-02-21 18:46:52'),
(10,	'Михаил Булгаков',	'Российская империя',	'Крещён в Крестовоздвиженской церкви на Подоле 18 мая. Крёстной матерью была его бабушка Олимпиада Ферапонтовна Булгакова[8], крёстным отцом — Николай Иванович Петров.',	'2024-02-21 15:48:47',	'2024-02-21 18:48:47'),
(11,	'Джейн Остен',	'Великобритания',	'Джейн О́стин, распространён также вариант Джейн О́стен (англ. Jane Austen, /dʒeɪn ˈɒstɪn/[1], 16 декабря 1775 — 18 июля 1817) — английская писательница, провозвестница реализма в британской литературе, сатирик, писала так называемые романы нравов. Её книги являются признанными шедеврами[2], которые сочетают в себе простоту сюжета, глубокое психологическое проникновение в души героев и ироничный, мягкий, истинно «английский» юмор.',	'2024-02-21 15:49:50',	'2024-02-21 18:49:50'),
(12,	'Эрих Ремарк',	'Германия',	'21 ноября 1916 года Ремарк был призван в армию, а 17 июня 1917 года направлен на Западный фронт. 31 июля 1917 года был ранен осколками гранаты в левую ногу, правую руку и шею. Остаток войны провёл в военных госпиталях Германии.',	'2024-02-21 15:50:51',	'2024-02-24 20:56:36'),
(13,	'Джек Лондон',	'США',	'После рождения малыша Флора оставила его на какое-то время, поручив его своей знакомой Дженни Принстер. Так темнокожая нянька заменила мать мальчику, для которого потом на протяжении всей его жизни оставалась важным человеком, и он всегда вспоминал об этой женщине с большой теплотой. В конце того же 1876 года Флора вышла замуж за фермера Джона Лондона, инвалида и ветерана Гражданской войны в США, который и усыновил ребёнка, дав ему свою фамилию.',	'2024-02-21 15:51:33',	'2024-02-21 18:51:33');

-- 2024-02-25 18:44:52
